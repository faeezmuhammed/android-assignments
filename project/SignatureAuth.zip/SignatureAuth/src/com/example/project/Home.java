package com.example.project;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.PixelFormat;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Menu;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;

import com.kau.lockmyapp.sign.ReSetSignature;
import com.kau.lockmyapp.sign.SetSignatureParameters;
import com.kau.lockmyapp.sign.customViewGroup;

public class Home extends Activity {
	Button b1,b2,b3,b4;
	SharedPreferences sp;	
//	private WindowManager manager;
//	private WindowManager.LayoutParams localLayoutParams;
    customViewGroup view;
    
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_home);
		
		b1=(Button)findViewById(R.id.button1);
		b2=(Button)findViewById(R.id.button2);
		b3=(Button)findViewById(R.id.button3);
		b4=(Button)findViewById(R.id.button4);
		
//		manager = ((WindowManager) getApplicationContext().getSystemService(Context.WINDOW_SERVICE));
//		
//		 android.view.WindowManager.LayoutParams localLayoutParams = new WindowManager.LayoutParams();
//		 localLayoutParams.type = WindowManager.LayoutParams.TYPE_SYSTEM_ERROR;
//		 localLayoutParams.gravity = Gravity.TOP;    
//
//		 localLayoutParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|		 
//		 WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN |
//		 WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH |		 // Draws over status bar
//		 WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
//
//		 localLayoutParams.height = (int) (50 * getResources().getDisplayMetrics().scaledDensity);
//		 localLayoutParams.format = PixelFormat.TRANSPARENT;
//
//		 view = new customViewGroup(this);
//		 manager.addView(view, localLayoutParams); 
		
		 sp = getSharedPreferences("lock_config", 0);			
			if(sp.getBoolean("flag", false) == false)
			{
				Toast.makeText(getApplicationContext(), "Please Restart Your Device !!!", Toast.LENGTH_LONG).show();
			}
		
			Editor e = sp.edit();
			e.putBoolean("flag", true);
			e.commit(); 
		
		b1.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
//				Intent i=new Intent(getApplicationContext(),MainSignature.class);
//				startActivity(i);
				Intent i=new Intent(getApplicationContext(), Starting.class);
				startActivity(i);
			}
		});
		b2.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent j=new Intent(getApplicationContext(),ReSetSignature.class);
				startActivity(j);
				finish();
			}
		});
		b3.setOnClickListener(new View.OnClickListener() {			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent j=new Intent(getApplicationContext(),SetSignatureParameters.class);
				startActivity(j);
				finish();
			}
		});
		b4.setOnClickListener(new View.OnClickListener() {			
			@Override
			public void onClick(View arg0) {
				Intent in=new Intent(Intent.ACTION_MAIN);
  				in.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
  				in.addCategory(Intent.CATEGORY_HOME);
  				startActivity(in);
  				finish();
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.home, menu);
		return true;
	}
	
	public void onBackPressed() 
	{
		android.os.Process.killProcess(android.os.Process.myPid());
	}

}
