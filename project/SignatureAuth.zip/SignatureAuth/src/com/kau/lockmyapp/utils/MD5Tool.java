package com.kau.lockmyapp.utils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class MD5Tool
{
  public static String toMD5(String paramString)
  {
    while (true)
    {
      int i;
      try
      {
        byte[] arrayOfByte = MessageDigest.getInstance("md5").digest(paramString.getBytes());
        StringBuffer localStringBuffer = new StringBuffer();
        i = 0;
        if (i >= arrayOfByte.length)
          return localStringBuffer.toString();
        String str = Integer.toHexString(0xFF & arrayOfByte[i]);
        if (str.length() == 1)
          localStringBuffer.append("0" + str);
        else
          localStringBuffer.append(str);
      }
      catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
      {
        localNoSuchAlgorithmException.printStackTrace();
        return "";
      }
      i++;
    }
  }
}