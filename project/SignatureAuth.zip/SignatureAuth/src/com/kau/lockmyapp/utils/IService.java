package com.kau.lockmyapp.utils;

public abstract interface IService
{
	
  public void setDoneSignAttempts(boolean result);

  public void setSignFinish(boolean logic);
  
}