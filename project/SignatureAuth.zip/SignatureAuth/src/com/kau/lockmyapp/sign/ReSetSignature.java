package com.kau.lockmyapp.sign;



import java.util.Locale;

import com.example.project.R;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.PixelFormat;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import napa.SignatureRecognition.Signature_templates;

public class ReSetSignature extends Activity {
	EditText e1;

	private WindowManager manager;
	private WindowManager.LayoutParams localLayoutParams;
   
    customViewGroup view;
	private static int userID,mode;
	private static SharedPreferences sp;
	public static final int TESTMODE = 1;
	public static final int TRAINMODE = 1;
	public static final int TOTAL_TEMPLATES = 5;	
	
	public static Signature_templates user_profile = new Signature_templates();



	@Override
	protected void onCreate(Bundle savedInstanceState) {		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.reset_message);	
		
		
		manager = ((WindowManager) getApplicationContext().getSystemService(Context.WINDOW_SERVICE));

		 android.view.WindowManager.LayoutParams localLayoutParams = new WindowManager.LayoutParams();
		 localLayoutParams.type = WindowManager.LayoutParams.TYPE_SYSTEM_ERROR;
		 localLayoutParams.gravity = Gravity.TOP;    

		 localLayoutParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|

//		 WindowManager.LayoutParams.FLAG_LAYOUT_ATTACHED_IN_DECOR |
		 WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN |

		 // this is to enable the notification to recieve touch events
//		 WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN |
		 WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH |
       // Draws over status bar
		 WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;


		 //localLayoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
		 localLayoutParams.height = (int) (50 *      getResources().getDisplayMetrics().scaledDensity);
		 localLayoutParams.format = PixelFormat.TRANSPARENT;

		 view = new customViewGroup(this);

		 manager.addView(view, localLayoutParams); 

		
		
///*--------------------------Home & Status--------------------------*/
//		
//		// Set the IMMERSIVE flag.
//	    // Set the content to appear under the system bars so that the content
//	    // doesn't resize when the system bars hide and show.
//	    this.getWindow().getDecorView().setSystemUiVisibility(
//	            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
//	            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
//	            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
//	            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION // hide nav bar
//	            | View.SYSTEM_UI_FLAG_FULLSCREEN // hide status bar
//	            | View.SYSTEM_UI_FLAG_IMMERSIVE);
//	    
//	    /*------------------------------End--------------------------------*/
//		
//		
		e1=(EditText)findViewById(R.id.editText1);
		
		
		sp = getSharedPreferences("lock_config", 0);
		
		
		Button btnContinue = (Button) findViewById(R.id.btnContinue);
		btnContinue.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				String a=e1.getText().toString();
				SharedPreferences.Editor editor = sp.edit();
		          editor.putString("uname", a);
		          editor.commit();
				try
				{
					  SQLiteDatabase sqldb =openOrCreateDatabase("project",SQLiteDatabase.CREATE_IF_NECESSARY ,null );
			          sqldb.setVersion(1);
			          sqldb.setLocale(Locale.getDefault());
			          String sql="create table if not exists signt(uname text primary key, template text)";
			          sqldb.execSQL(sql);
			          String s="select * from signt where uname='"+a+"'"; 
			          Cursor cr=sqldb.rawQuery(s, null);
		              if(cr.getCount()!=0)
		              {
		            	Toast.makeText(getApplicationContext(),"Reset Your Sign Here" ,Toast.LENGTH_LONG).show();  
		            	 startActivity(new Intent(ReSetSignature.this, ReSetSignLockScreenActivity.class));
							try {
									ReSetSignature.this.finish();
								} catch (Throwable e) {
									e.printStackTrace();
								}
			             
		              }
		              else{
			          
				          Toast.makeText(getApplicationContext(), "Not Registered !", Toast.LENGTH_SHORT).show();
				          e1.setText("");
						 	
		              }
		        }
				catch(Exception e)
				{
					Toast.makeText(getApplicationContext(), ""+e.getMessage(), Toast.LENGTH_LONG).show();
				}
		
				
		}
		});
		
}
	
	public static int getUserID() {
		return userID;
	}
	
	public static int getMode() {
		return mode;
	}
	
	/*
	public static boolean isTrainingMode() {
		if(sp.getInt("mode", 1) == TESTMODE) {
			return false;
		}
		return true;
	}
	*/
}
