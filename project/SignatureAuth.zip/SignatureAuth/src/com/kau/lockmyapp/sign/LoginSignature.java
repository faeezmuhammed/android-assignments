package com.kau.lockmyapp.sign;

import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

import napa.SignatureRecognition.Signature_templates;
import android.app.Activity;
import android.app.KeyguardManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.PixelFormat;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.project.R;

public class LoginSignature extends Activity {
	EditText e1;
	private static int userID,mode;
	private static SharedPreferences sp;
	public static final int TESTMODE = 1;
	public static final int TRAINMODE = 1;
	public static final int TOTAL_TEMPLATES = 5;	
	
	public static Signature_templates user_profile = new Signature_templates();
//	private WindowManager manager;
//	private WindowManager.LayoutParams localLayoutParams;
   
//    customViewGroup view;
	int count = 0;
	int n=0;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login_message);	
		
//		manager = ((WindowManager) getApplicationContext().getSystemService(Context.WINDOW_SERVICE));
//
//		 android.view.WindowManager.LayoutParams localLayoutParams = new WindowManager.LayoutParams();
//		 localLayoutParams.type = WindowManager.LayoutParams.TYPE_SYSTEM_ERROR;
//		 localLayoutParams.gravity = Gravity.TOP;    
//
//		 localLayoutParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|
//
////		 WindowManager.LayoutParams.FLAG_LAYOUT_ATTACHED_IN_DECOR |
//		 WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN |
//
//		 // this is to enable the notification to recieve touch events
////		 WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN |
//		 WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH |
//        // Draws over status bar
//		 WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
//
//
//		 //localLayoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
//		 localLayoutParams.height = (int) (50 *      getResources().getDisplayMetrics().scaledDensity);
//		 localLayoutParams.format = PixelFormat.TRANSPARENT;
//
//		 view = new customViewGroup(this);
//
//		 manager.addView(view, localLayoutParams); 
		
       	 //Lock_screen.flag = 1;
		
		 Toast.makeText(getApplicationContext(), "Please Login to Continue !!!", Toast.LENGTH_LONG).show();
		 
//		 HomeKeyLocker homeKeyLocker = new HomeKeyLocker();
//       	 homeKeyLocker.unlock();
		
///*--------------------------Home & Status--------------------------*/
//		
//		// Set the IMMERSIVE flag.
//	    // Set the content to appear under the system bars so that the content
//	    // doesn't resize when the system bars hide and show.
//	    this.getWindow().getDecorView().setSystemUiVisibility(
//	            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
//	            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
//	            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
//	            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION // hide nav bar
//	            | View.SYSTEM_UI_FLAG_FULLSCREEN // hide status bar
//	            | View.SYSTEM_UI_FLAG_IMMERSIVE);
//	    
//	    /*------------------------------End--------------------------------*/
//		
		
		e1=(EditText)findViewById(R.id.editText1);
		sp = getSharedPreferences("lock_config", 0);		
		
		Button btnContinue = (Button) findViewById(R.id.btnContinue);
		btnContinue.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				String a=e1.getText().toString();
				if(a.equals(""))
				{
					e1.setError("Enter username");
				}
				else
				{
				  SharedPreferences.Editor editor = sp.edit();
		          editor.putString("uname", a);
		          editor.commit();
		          try
		          {
					  SQLiteDatabase sqldb =openOrCreateDatabase("project",SQLiteDatabase.CREATE_IF_NECESSARY ,null );
			          sqldb.setVersion(1);
			          sqldb.setLocale(Locale.getDefault());
			          String sql="create table if not exists signt(uname text primary key, template text)";
			          sqldb.execSQL(sql);
			          String s="select * from signt where uname='"+a+"'"; 
			          Cursor cr=sqldb.rawQuery(s, null);
		              if(cr.getCount()!=0)
		              {
		            	  Intent intent = new Intent(LoginSignature.this, SignLockScreenActivity1.class);
						  intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
						  startActivity(intent);
						  try {
							  //Lock_screen.flag = 0;
			            	  LoginSignature.this.finish();
						  } catch (Throwable e) {
							e.printStackTrace();
						  }
					}
		        }
				catch(Exception e)
				{
					Toast.makeText(getApplicationContext(), ""+e.getMessage(), Toast.LENGTH_LONG).show();
				}
			}
		}
	});		
}
	
	public static int getUserID() {
		return userID;
	}
	
	public static int getMode() {
		return mode;
	}
	
	Timer timer;
	MyTimerTask myTimerTask;
	
	private void bringApplicationToFront()
	{
	    KeyguardManager myKeyManager = (KeyguardManager)getSystemService(Context.KEYGUARD_SERVICE);
	    if( myKeyManager.inKeyguardRestrictedInputMode())
	        return;

	    Log.d("TAG", "====Bringging Application to Front====");

	    Intent notificationIntent = new Intent(this, LoginSignature.class);
	    notificationIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
	    PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, 0);
	    try
	    {
	        pendingIntent.send();
	    }
	    catch (PendingIntent.CanceledException e)
	    {
	        e.printStackTrace();
	    }		
	}

	public void onBackPressed() {
	     //do not call super onBackPressed.
	}

	@Override
	protected void onResume() {
	    super.onResume();
	    
//	    if(Lock_screen.flag == 1)
//	    {
//		    if (timer != null) {
//		        timer.cancel();
//		        timer = null;
//		    } 
//	    }
	}
	
	public class MyTimerTask extends TimerTask {
	 
	  
	    
	    public void run() {
	    	 count++;
	    	 
	         if (count <= 200) {
	        	   bringApplicationToFront();
	         }
	         else{ n++;}
	         if(n==1)
	         {
	        	
	        	 timer=null;
	        	 runOnUiThread(new Runnable() {
						
						@Override
						public void run() {
							final Toast tag=Toast.makeText(getBaseContext(), "Now you can start", Toast.LENGTH_LONG);
							// TODO Auto-generated method stub
							tag.show();
							new CountDownTimer(2000, 1000) {

						          public void onTick(long millisUntilFinished) {
						        	  tag.show();
						          }
						          public void onFinish()
						          {tag.show();}
							}.start();
						
						}
					});
	        	 }
	    	}
	    
		}
	protected void onPause()
	{
//		if(Lock_screen.flag == 1)
//		{
//		    if (timer == null) {
//		        myTimerTask = new MyTimerTask();
//		        timer = new Timer();
//		        timer.schedule(myTimerTask, 100,100);	      	
//		    }
//		}

	    super.onPause();
	}
	
	/*
	public static boolean isTrainingMode() {
		if(sp.getInt("mode", 1) == TESTMODE) {
			return false;
		}
		return true;
	}
	*/
}
