package com.kau.lockmyapp.sign;

import java.util.ArrayList;

import napa.SignatureRecognition.Point;
import android.content.Context;
import android.graphics.*;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;



    public class BitmapView extends View {

        private Bitmap  mBitmap;
        private Canvas  mCanvas;
        private Path    mPath;
        private Paint   mBitmapPaint;
        private Paint   mPaint;
        
        public static Button btnReset;
        public static Button btnNext;
		private LayoutParams params;
        int width;
        int height;
        
        public static ArrayList<ArrayList<Point>> interaction = new ArrayList<ArrayList<Point>>();
        public static final String TAG = "BitmapView";
		public static final String TOUCH = "touch";
		public static final String MOVE = "move";
		public static final String END = "end";
		
		public BitmapView(final Context context, AttributeSet attributeSet) {
			super(context, attributeSet);    
			
			DisplayMetrics metrics = context.getResources().getDisplayMetrics();
			int width = metrics.widthPixels;
			int height = metrics.heightPixels;

			mBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            mCanvas = new Canvas(mBitmap);
            mPath = new Path();
            mBitmapPaint = new Paint(Paint.DITHER_FLAG);
            
            mPaint = new Paint();
            mPaint.setAntiAlias(true);
            mPaint.setDither(true);
            mPaint.setColor(Color.GREEN); 
            mPaint.setStyle(Paint.Style.STROKE);
            mPaint.setStrokeJoin(Paint.Join.ROUND);
            mPaint.setStrokeCap(Paint.Cap.ROUND);
            mPaint.setStrokeWidth(12);
            
            btnReset = new Button(context);
			btnReset.setBackgroundColor(Color.RED);
			params = new LayoutParams(LayoutParams.WRAP_CONTENT,
					LayoutParams.WRAP_CONTENT);
			btnReset.setLayoutParams(params);
			
			btnNext = new Button(context);
			btnNext.setBackgroundColor(Color.GREEN);
			btnNext.setLayoutParams(params);
			
			
			btnReset.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					mPath.reset();
					mBitmap.eraseColor(0xFF000000);	
					postInvalidate();
				}
			});
        }
        
        @Override
        protected void onDraw(Canvas canvas) {
            canvas.drawColor(0xFF000000);  //0xFFAAAAAA
            canvas.drawBitmap(mBitmap, 0, 0, mBitmapPaint);
            canvas.drawPath(mPath, mPaint);
        }

        private float mX, mY;
        private static final float TOUCH_TOLERANCE = 4;

        private void touch_start(float x, float y) {
            mPath.reset();
            mPath.moveTo(x, y);
            mX = x;
            mY = y;
        }
        private void touch_move(float x, float y) {
            float dx = Math.abs(x - mX);
            float dy = Math.abs(y - mY);
            if (dx >= TOUCH_TOLERANCE || dy >= TOUCH_TOLERANCE) {
                mPath.quadTo(mX, mY, (x + mX)/2, (y + mY)/2);
                mX = x;
                mY = y;
            }
        }
        private void touch_up() {
            mPath.lineTo(mX, mY);
            mCanvas.drawPath(mPath, mPaint);
            mPath.reset();
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
        	
        	DrawSignature.isTouched = true;
        	
        	float x = event.getX();
            float y = event.getY();
            
        	//Create Interactions
			ArrayList<Point> currentSet = new ArrayList<Point>();
	    	final int historySize = event.getHistorySize();
	    	for (int h = 0;h<historySize;h++)
	    	{
	    		for (int i = 0;i<event.getPointerCount();i++)
	    		{
	            	Point point = new Point(event.getHistoricalX(i, h),event.getHistoricalY(i, h),event.getHistoricalPressure(i, h),
	            			event.getHistoricalToolMinor(i, h),event.getHistoricalOrientation(i, h),2);
	            	currentSet.add(point);    		
	    		}
	        	interaction.add(currentSet);
	        	currentSet = new ArrayList<Point>();         	
	    	}    	
	    	for (int i = 0;i<event.getPointerCount();i++)
	    	{
	            Point point = new Point(event.getX(i),event.getY(i),event.getPressure(i),event.getSize(i),
	            		event.getOrientation(i),event.getActionMasked());
	            x = event.getX(i);
	            y = event.getY(i);
	            
	            currentSet.add(point); 		
	    	}
	    	interaction.add(currentSet);
	    	
	    	
	    	if(isTrainingMode()) {
	    		DrawSignature.enableNextButton();
	    	} else {
	    		SignLockScreenActivity1.enableSignButton();
	    	}	    	
	    	
	    	// crashes here because of ininitiated statics
	    	DrawSignature.pointXArr.add(x);
	    	DrawSignature.pointYArr.add(y);
	    	DrawSignature.timestampArr.add(System.currentTimeMillis() % 1000);

            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    touch_start(x, y);
                    DrawSignature.eventTypeArr.add(TOUCH);
                    invalidate();
                    break;
                case MotionEvent.ACTION_MOVE:
                    touch_move(x, y);
                    DrawSignature.eventTypeArr.add(MOVE);
                    invalidate();
                    break;
                case MotionEvent.ACTION_UP:
                    touch_up();
                    DrawSignature.eventTypeArr.add(END);
                    invalidate();
                    break;
            }
            return true;
        }
        
        
        
    	public boolean isTrainingMode() {
    		
	    	int mode = getContext().getSharedPreferences("lock_config", 0).getInt("mode", 1);
	    	
    		if(mode == MainSignature.TESTMODE) {
    			return false;
    		}
    		return true;
    	}
    }

