package com.kau.lockmyapp.sign;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Locale;

import napa.SignatureRecognition.Point;
import napa.SignatureRecognition.Signature;
import napa.SignatureRecognition.Signature_templates;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.project.Home;
import com.example.project.R;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.InstanceCreator;

public class SignLockScreenActivity1 extends Activity {
	//generic variables		
	private SharedPreferences sp;
	private String str;
	private int attemptCnt = 0;
	private static final int SIGNATURE_ATTEMPTS = 2;			
	
	//application specific variables	
	private Button btnErase;
	private static Button btnSign;
	private TextView txt_signView, txt_msgView;
	private View signView;
	private int longAnimDuration;
	private double dwt_threshold;
	private double hist_threshold;
	private double score_DTW;
	private double score_hist;
	
	Handler hd=new Handler();	
	
	public static boolean isTouched = false;	

	private WindowManager manager;
	
    customViewGroup view;
    
	@Override
	public void onBackPressed() {
	    // Do nothing
	}

	
	// destroy if home or back pressed
	protected void onStop() {
		super.onStop();		
		finish();
	}	
	
	
	@Override
	protected void onDestroy() {		
		super.onDestroy();
	}
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);		
	    initService();
		initUI();
	}	
	
	//This is to initialize service
	private void initService()
	{
		sp = getSharedPreferences("lock_config", 0);
		loadTemplates(sp);		
		
	}
		
	//Call when the credential is not authentic and attempts are finished	
	private void failAuthenticate()
	{
		attemptCnt = 0;					
		txt_signView.setEnabled(false);
	}

	
	//****Application specific method	
	
	class SignatureInstanceCreator implements InstanceCreator<Signature> {
		   public Signature createInstance(Type type) {
		     return new Signature(null);
		   }
	}	

	//This is to initialize UI	
	private void initUI()
	{
		setContentView(R.layout.login_sign_n_unlock);	
		
//		manager = ((WindowManager) getApplicationContext().getSystemService(Context.WINDOW_SERVICE));
//
//		 android.view.WindowManager.LayoutParams localLayoutParams = new WindowManager.LayoutParams();
//		 localLayoutParams.type = WindowManager.LayoutParams.TYPE_SYSTEM_ERROR;
//		 localLayoutParams.gravity = Gravity.TOP;    
//
//		 localLayoutParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|
//		 
//		 WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN |
//
//		 WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH |
//		 // Draws over status bar
//		 WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
//
//		 localLayoutParams.height = (int) (50 *      getResources().getDisplayMetrics().scaledDensity);
//		 localLayoutParams.format = PixelFormat.TRANSPARENT;
//
//		 view = new customViewGroup(this);
//
//		 manager.addView(view, localLayoutParams); 
//
//		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);	//napa
		
		//View objects

		btnErase = (Button) findViewById(R.id.btnErase);
		btnSign = (Button) findViewById(R.id.btnSign);
		btnSign.setEnabled(true);
		txt_signView = (TextView) findViewById(R.id.txt_signView); 
		txt_msgView = (TextView) findViewById(R.id.txt_msg);
		signView = findViewById(R.id.signview);		
		
		//CROSSFADE ANIMATION - Hide visibility of signView		
		//txt_signView.setText("Sign here to unlock this app");
		txt_signView.setVisibility(View.VISIBLE);				
//		longAnimDuration = 3000;						
		SignLockScreenActivity1.this.crossfade();				
		
		//ERASE BUTTON ONCLICK				
		btnErase.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				LoginBitmapView.btnReset.callOnClick();
			}		
		});	
		
		//SIGN BUTTON ONCLICK				
		btnSign.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {				
				if(sp.getInt("mode", 1) == LoginSignature.TESTMODE) {	
					
					if(isTouched)   
					{
						
						if(isSignatureVerified(LoginBitmapView.interaction)) 
						{
//							 Intent in=new Intent(Intent.ACTION_MAIN);
//			   				 in.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//			   				 in.addCategory(Intent.CATEGORY_HOME);
//			   				 startActivity(in);
							
							Intent intent = new Intent(SignLockScreenActivity1.this,Home.class);
						    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
							startActivity(intent);
							
			   				 finish();
						}
						else 
							retry();

						isTouched = false;
					}
					else
					{
						Toast.makeText(getApplicationContext(), "Please Sign to Continue !!!", Toast.LENGTH_LONG).show();
					}
				}
			}
		});		
	}
	
	//Call when the credential is not authentic and attempts are not finished
	private void retry()
	{
		txt_msgView.setTextColor(Color.RED);
		if(attemptCnt >= SIGNATURE_ATTEMPTS) 
		{
			failAuthenticate();				//Done sign attempt	
//			Toast.makeText(getApplicationContext(), "Invalid Signature! Wait for 30 seconds...!", Toast.LENGTH_LONG).show();
			Toast.makeText(getApplicationContext(), "Invalid Signature!!", Toast.LENGTH_LONG).show();
			
//			startActivity(new Intent(getApplicationContext(), Lock_screen.class)); 
			hd.postDelayed(r, 1000);
			HomeKeyLocker homeKeyLocker = new HomeKeyLocker();
          	homeKeyLocker.unlock();
		}
		else 
		{
			SignLockScreenActivity1.this.crossfade();
			txt_msgView.setText("Invalid Signature !\n"+"Attempt: " +Integer.toString(attemptCnt+1));
		    attemptCnt++;
			resetDataAndUI();
		}				
	}

	//This is to reset authentication credential data and UI after a failed attempt has been made
	private void resetDataAndUI()
	{
		LoginBitmapView.btnReset.callOnClick();
		LoginBitmapView.interaction = new ArrayList<ArrayList<Point>>();
		btnSign.setEnabled(false);
	}
	
	//This is to load credential template from SharedPreferences
	private void loadTemplates(SharedPreferences sp) 
	{
		 String un=sp.getString("uname", "");
		 SQLiteDatabase sqldb =openOrCreateDatabase("project",SQLiteDatabase.CREATE_IF_NECESSARY ,null );
	     sqldb.setVersion(1);
	     sqldb.setLocale(Locale.getDefault());
	     String sql="create table if not exists signt(uname text primary key, template text)";
	     sqldb.execSQL(sql);
	     String s="select * from signt where uname='"+un+"'"; 
	     Cursor cr=sqldb.rawQuery(s, null);
	     
	     String u="";
	     if(cr.getCount()!=0)
	     {
	    	 cr.moveToNext();
	    	 u=cr.getString(1);    	 
	     }
     	 if(sp.getInt("mode", 1) == LoginSignature.TESTMODE) {
			
				Gson gson = new GsonBuilder().registerTypeAdapter(Signature.class, new SignatureInstanceCreator()).create();
				String json;				
				Signature temp;
				ArrayList<Signature> templates = new ArrayList<Signature>();
					  String res[]=u.split("#@#");
					  for(String result : res)
					  {
						 json = result;
						 temp = gson.fromJson(json, Signature.class);
						 templates.add(temp);
					  }
				if(templates.size() == 5) {
					LoginSignature.user_profile.setTemplates(templates);	
				} else {}
		} else {}
	}
	
		
	private void crossfade() {
		txt_signView.setAlpha(0f);
		txt_signView.setVisibility(View.VISIBLE);
		txt_signView.animate().alpha(1f).setDuration(longAnimDuration).setListener(null);	
		
		signView.animate().alpha(1f).setDuration(longAnimDuration).setListener(new AnimatorListenerAdapter() {
			@Override
			public void onAnimationEnd(Animator animation) {
				txt_signView.setVisibility(View.GONE);
				signView.setVisibility(View.VISIBLE);				
			}
		});
	}
	
	private boolean isSignatureVerified(ArrayList<ArrayList<Point>> rawInteraction) {    	
    	boolean result = false;

    	if (LoginSignature.user_profile.getTraingingSamplesCount()==LoginSignature.TOTAL_TEMPLATES) {
    		ArrayList<ArrayList<Point>> matchInteraction = new ArrayList<ArrayList<Point>>();
    		for (int j = 0;j<rawInteraction.size();j++) {
    				matchInteraction.add(rawInteraction.get(j));
    		}
    		
    		double[] score = LoginSignature.user_profile.distance_score(matchInteraction);
    		score_DTW = score[0];
    		score_hist = score[1];

    		dwt_threshold = sp.getFloat("dwt_threshold", 0);
    		hist_threshold = sp.getFloat("hist_threshold", 0);
    		
    		if(dwt_threshold == 0 || dwt_threshold == 2 ) {
    			dwt_threshold = Signature_templates.getDWTThreshold();
    		}
    		if(hist_threshold == 0 || hist_threshold == 30) {
    			
    			hist_threshold = Signature_templates.getHISTThreshold();
    		}
    		
//    		Toast.makeText(getApplicationContext(), dwt_threshold+" "+hist_threshold, Toast.LENGTH_LONG).show();
    		
    		if ((score_DTW <= dwt_threshold) && (score_hist <= hist_threshold)) { 
    			result = true;
    		}
    		matchInteraction.clear();
    		
    	}    	
    	return result;
    }
		
	public static void enableSignButton() {
		if(btnSign != null) {
			btnSign.setEnabled(true);
		}
	}
	
	Runnable r=new Runnable() {
		
		@Override
		public void run() {
			try {				
				Intent i=new Intent(getApplicationContext(),LoginSignature.class);
				startActivity(i);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	};

}