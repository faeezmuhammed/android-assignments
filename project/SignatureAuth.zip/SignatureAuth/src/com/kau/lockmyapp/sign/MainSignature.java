package com.kau.lockmyapp.sign;



import java.util.Locale;

import napa.SignatureRecognition.Signature_templates;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.PixelFormat;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.project.R;

public class MainSignature extends Activity {
	EditText e1;
	private static int userID,mode;
	private static SharedPreferences sp;
	public static final int TESTMODE = 1;
	public static final int TRAINMODE = 1;
	public static final int TOTAL_TEMPLATES = 5;	
	
	public static Signature_templates user_profile = new Signature_templates();	
	private WindowManager manager;	
    customViewGroup view;
    
	@Override
	protected void onCreate(Bundle savedInstanceState) {		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.message);	
		
		manager = ((WindowManager) getApplicationContext().getSystemService(Context.WINDOW_SERVICE));

		 android.view.WindowManager.LayoutParams localLayoutParams = new WindowManager.LayoutParams();
		 localLayoutParams.type = WindowManager.LayoutParams.TYPE_SYSTEM_ERROR;
		 localLayoutParams.gravity = Gravity.TOP;    

		 localLayoutParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|

		 WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN |

		 WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH |
         // Draws over status bar
		 WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;


		 localLayoutParams.height = (int) (50 *      getResources().getDisplayMetrics().scaledDensity);
		 localLayoutParams.format = PixelFormat.TRANSPARENT;

		 view = new customViewGroup(this);

		 manager.addView(view, localLayoutParams); 

		 HomeKeyLocker homeKeyLocker = new HomeKeyLocker();
       	 homeKeyLocker.unlock();
	
		e1=(EditText)findViewById(R.id.editText1);
		
		
		sp = getSharedPreferences("lock_config", 0);
		
		Button btnContinue = (Button) findViewById(R.id.btnContinue);
		btnContinue.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				String a=e1.getText().toString();
				if(a.equals(""))
				{
					e1.setError("Enter username");
				}
				else
				{
					SharedPreferences.Editor editor = sp.edit();
		            editor.putString("uname", a);
		            editor.putBoolean("flag", true);
		            editor.commit();
				try{
					  SQLiteDatabase sqldb =openOrCreateDatabase("project",SQLiteDatabase.CREATE_IF_NECESSARY ,null );
			          sqldb.setVersion(1);
			          sqldb.setLocale(Locale.getDefault());
			          String sql="create table if not exists signt(uname text primary key, template text)";
			          sqldb.execSQL(sql);
			          String s="select * from signt where uname='"+a+"'"; 
			          Cursor cr=sqldb.rawQuery(s, null);
		              if(cr.getCount()!=0)
		              {
		            	  Toast.makeText(getApplicationContext(),"Already Inserted" ,Toast.LENGTH_LONG).show();  			             
		              }
		              else
		              {
						  ContentValues cv=new ContentValues();
				          cv.put("uname",a );
				          cv.put("template","" );
				          sqldb.insert("signt", null, cv);
				          
				          Toast.makeText(getApplicationContext(), "Inserted", Toast.LENGTH_SHORT).show();
				          e1.setText("");
					  
						  sqldb.close();
							
						  Intent intent = new Intent(MainSignature.this, DrawSignature.class);
						  intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
						  startActivity(intent);
						  
						  	try {
									MainSignature.this.finish();
								} catch (Throwable e) {
									e.printStackTrace();
								}
						}
		              }
				catch(Exception e)
				{
					Toast.makeText(getApplicationContext(), ""+e.getMessage(), Toast.LENGTH_LONG).show();
				}
		
				
		}
		}});
		
}
	
	public static int getUserID() {
		return userID;
	}
	
	public static int getMode() {
		return mode;
	}
	
	public void onBackPressed() {
	     //do not call super onBackPressed.
	}

}
