package com.kau.lockmyapp.sign;

import java.util.ArrayList;

import napa.SignatureRecognition.Point;
import napa.SignatureRecognition.Signature;
import android.accounts.Account;
import android.accounts.AccountManager;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Bundle;
import android.provider.Settings.Secure;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.project.Home;
import com.example.project.R;
import com.google.gson.Gson;



public class ReSetDrawSignature extends Activity {

	private WindowManager manager;
	private WindowManager.LayoutParams localLayoutParams;
   
    customViewGroup view;
	

	//private final static int ITERATIONS = 5;
	private static int counter = 1;
	//private static int training_counter = 3;

	private Button btnErase;
	private static Button btnNext;
	private TextView txt_signView;
	private View signView;
	private int longAnimDuration;
	private SharedPreferences sp;
	private static String android_id;
	//private static String android_username;
	private static final int MIN_SEQ = 3;
	 String un="";
	public static ArrayList<String> json_templates = new ArrayList<String>();

	private static final String TAG = "ReSetDrawSignature";

	public static ArrayList<Float> pointXArr;
	public static ArrayList<Float> pointYArr;
	public static ArrayList<String> eventTypeArr;
	public static ArrayList<Long> timestampArr;
	
	public static boolean isTouched = false;
	
	static{
		pointXArr = new ArrayList<Float>();
		pointYArr = new ArrayList<Float>();
		eventTypeArr = new ArrayList<String>();
		timestampArr = new ArrayList<Long>();
	}
	protected void onStop() {
	    ReSetSignature.user_profile.clearAllTemplate();		
		super.onStop();							    
	}

	@Override
	public void onBackPressed() {
	    ReSetSignature.user_profile.clearAllTemplate();		
	    super.onBackPressed();
	}
	public void resetDone()
	{
		SharedPreferences.Editor editor = sp.edit();
		editor.putBoolean("isSignatureSet", true);
		editor.commit();
		storeTemplates();
		Intent intent = new Intent(ReSetDrawSignature.this, Home.class);
		startActivity(intent);
		finish();		
	}
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.reset_activity_sig);
		
		manager = ((WindowManager) getApplicationContext().getSystemService(Context.WINDOW_SERVICE));

		 android.view.WindowManager.LayoutParams localLayoutParams = new WindowManager.LayoutParams();
		 localLayoutParams.type = WindowManager.LayoutParams.TYPE_SYSTEM_ERROR;
		 localLayoutParams.gravity = Gravity.TOP;    

		 localLayoutParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|

//		 WindowManager.LayoutParams.FLAG_LAYOUT_ATTACHED_IN_DECOR |
		 WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN |

		 // this is to enable the notification to recieve touch events
//		 WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN |
		 WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH |
       // Draws over status bar
		 WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;


		 //localLayoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
		 localLayoutParams.height = (int) (50 *      getResources().getDisplayMetrics().scaledDensity);
		 localLayoutParams.format = PixelFormat.TRANSPARENT;

		 view = new customViewGroup(this);

		 manager.addView(view, localLayoutParams); 

		
		
		
		
///*--------------------------Home & Status--------------------------*/
//		
//		// Set the IMMERSIVE flag.
//	    // Set the content to appear under the system bars so that the content
//	    // doesn't resize when the system bars hide and show.
//	    this.getWindow().getDecorView().setSystemUiVisibility(
//	            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
//	            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
//	            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
//	            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION // hide nav bar
//	            | View.SYSTEM_UI_FLAG_FULLSCREEN // hide status bar
//	            | View.SYSTEM_UI_FLAG_IMMERSIVE);
//	    
//	    /*------------------------------End--------------------------------*/
//		

		//Initialize SharedPreference
		sp = getSharedPreferences("lock_config", 0);
		SharedPreferences.Editor editor = sp.edit();
        un=sp.getString("uname", "");
		//SET ANDROID DEVICE ID
		android_id = sp.getString("android_id", "");
		if(android_id.equals("")) {
			android_id = getAndroidId();
			editor.putString("android_id", android_id);
		}

		ReSetSignature.user_profile.clearAllTemplate();
		
//		//SET ANDROID USERNAME
//    	android_username = sp.getString("android_username", "");
//    	if(android_username.equals("")) {
//    		//android_username = getAndroidUserName();
//    		android_username="2";
//    		editor.putString("android_username", android_username);
//    	}
//
//    	//SET TRAINING COUNTER
//		training_counter = sp.getInt("training_counter", 1);
//		editor.putInt("training_counter", training_counter+1);
//		editor.commit();

		//View objects
		final TextView txt_msg = (TextView) findViewById(R.id.txt_msg);
		txt_msg.setBackgroundColor(Color.DKGRAY); 
		btnErase = (Button) findViewById(R.id.btnErase);
		btnNext = (Button) findViewById(R.id.btnNext);
		btnNext.setEnabled(true);
		txt_signView = (TextView) findViewById(R.id.txt_signView);
		signView = findViewById(R.id.signview);

		//CROSSFADE ANIMATION - Hide visibility of signView
		txt_signView.setVisibility(View.VISIBLE);
		longAnimDuration = 3000;
		ReSetDrawSignature.this.crossfade();


		//ERASE BUTTON ONCLICK
		btnErase.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				isTouched = false; 
				ReSetBitmapView.btnReset.callOnClick();
				clearData();   
				//path.reset();
			}
		});


		//NEXT BUTTON ONCLICK
		btnNext.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {

				if(sp.getInt("mode", 1) == ReSetSignature.TRAINMODE) {
					//Log.d(TAG, ReSetBitmapView.interaction.toString());
					Log.d(TAG, "Training mode...");

					if(isTouched)   
					{
						
						//Add interaction to template
						onTrain(ReSetBitmapView.interaction);
	
						longAnimDuration = 1000;
						String device_id = sp.getString("android_id", "");
	
						//Send Data to server
						if(sp.getInt("mode", 1) == ReSetSignature.TRAINMODE) {
							Log.d(TAG, "Sending data to server...");
							Log.d(TAG, "pointXArr: " + pointXArr.toString());
	//						new ReportGenerationTask(DrawSignature.this, device_id, pointXArr, pointYArr,
	//							eventTypeArr, timestampArr, counter, training_counter).execute(ReSetSignature.URL);
						}
						txt_signView.setTextColor(Color.WHITE);
						
						switch(ReSetSignature.user_profile.getTraingingSamplesCount()) {
							case 1:
								txt_signView.setText("Four more to go!");
								txt_msg.setText("Four more!");
								break;
							case 2:
								txt_signView.setText("Three more to go!");
								txt_msg.setText("Three more!");
								break;
							case 3:
								txt_signView.setText("Two more to go!");
								txt_msg.setText("Two more!");
								break;
							case 4:
								txt_signView.setText("One more to go!");
								txt_msg.setText("One more!");
								break;
							
		
							default:
								txt_signView.setText("Training Mode");
								break;
						}
						ReSetDrawSignature.this.crossfade();
						isTouched = false;
						counter++;
					}
					else
					{
						Toast.makeText(getApplicationContext(), "Please Sign to Continue !!!", Toast.LENGTH_LONG).show();
					}

					//IF DONE WITH TRAINING
					if ( ReSetSignature.user_profile.getTraingingSamplesCount()==ReSetSignature.TOTAL_TEMPLATES) {
						Log.d(TAG, "User training completed.");						
						Log.d(TAG, "Templates are stored.");
						//reset++;s
						Toast.makeText(getApplicationContext(), "ert", Toast.LENGTH_LONG).show();
						counter = 1;
						resetDone();
					}
					
				}
				ReSetBitmapView.btnReset.callOnClick();
				ReSetBitmapView.interaction = new ArrayList<ArrayList<Point>>();
				btnNext.setEnabled(true);
			}


		});
	}
	public void storeTemplates() {
		ArrayList<Signature> templates = ReSetSignature.user_profile.getTemplates();
		if(templates.size() > 0) { // && sp.getString("my_templates", "") == "") {
			//sp = getSharedPreferences("lock_config", 0);
			SharedPreferences.Editor editor = sp.edit();
			//SET MODE TO TEST
			Log.d(TAG, "hereeeee....setting mode to test");
			editor.putInt("mode", ReSetSignature.TESTMODE);
			//STORE TEMPLATES
			Gson gson = new Gson();
			int i=1;
			String json="";
			for (Signature template : templates) {
				 json =json+ gson.toJson(template)+"#@#";
				//json_templates.add(json);
//				Toast.makeText(getApplicationContext(), "json"+json, Toast.LENGTH_LONG).show();
				Log.d(TAG, "JSON" + i + ": " + json);
				//editor.putString("my_templates" + i, json);
				
				i++;
			}
			editor.commit();

			SQLiteDatabase db=openOrCreateDatabase("project", SQLiteDatabase.CREATE_IF_NECESSARY, null);
			 String sql="create table if not exists signt(uname text primary key, template text)";
	         db.execSQL(sql);
//			TelephonyManager mng=(TelephonyManager)getSystemService(Context.TELEPHONY_SERVICE);
//			String ime=mng.getDeviceId();
		   String re="update signt set template='"+json+"' where uname='"+un+"'";
		   db.execSQL(re);
	       
	      
           db.close();
			//Send templates
//			if(json_templates.size() > 0) {
//				String device_id = sp.getString("android_id", "");
//				new SendTemplates(DrawSignature.this, json_templates, training_counter, device_id).execute(ReSetSignature.URL);
//			}
        	} else {
        		Log.d(TAG, "Template already exists!");
	}
	}
	public static void clearData() {
		pointXArr.clear();
		pointYArr.clear();
		eventTypeArr.clear();
		timestampArr.clear();
	}

	private String getAndroidId() {
		String android_id = Secure.getString(getContentResolver(),Secure.ANDROID_ID);
		return android_id;
	}

	private String getAndroidUserName() {
		AccountManager accountManager = AccountManager.get(this);
	    Account[] accounts = accountManager.getAccountsByType("com.google");
	    if(accounts.length==0) {return "Anonymous";}
	    String username = accounts[0].name;
	    if(username.equals(null) || username.equals("")) {
	    	username = "Anonymous";
	    }
		return username;
	}

	private void crossfade() {
		txt_signView.setAlpha(0f);
		txt_signView.setVisibility(View.VISIBLE);
	txt_signView.animate().alpha(1f).setDuration(longAnimDuration).setListener(null);

		signView.animate().alpha(1f).setDuration(longAnimDuration).setListener(new AnimatorListenerAdapter() {
			@Override
			public void onAnimationEnd(Animator animation) {
				txt_signView.setVisibility(View.GONE);
				signView.setVisibility(View.VISIBLE);
			}
		});
	}

	private void onTrain(ArrayList<ArrayList<Point>> rawInteraction) {
    	int i = 0;
    	while (i<rawInteraction.size()) {
    		if (rawInteraction.get(i).size()!=1) {
    			Log.v("kau", i + "th Interaction arraylist elemnent is one, hence remove");
    			rawInteraction.get(i).clear();
    			rawInteraction.remove(i);
    		} else {// just one
    			i = i+1;
    		}
    	}

    	if (rawInteraction.size()<MIN_SEQ) {
    		Log.v(TAG, "Invalid Interaction" );
    	} else {
    		ReSetSignature.user_profile.addTemplate(rawInteraction);
    		Log.d(TAG, "Template " + ReSetSignature.user_profile.getTraingingSamplesCount() +" is added!");
    	}
    }

	public static void enableNextButton() {
		btnNext.setEnabled(true);
	}

}