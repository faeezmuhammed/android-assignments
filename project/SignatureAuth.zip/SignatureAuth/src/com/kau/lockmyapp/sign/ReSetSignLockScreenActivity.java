package com.kau.lockmyapp.sign;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Locale;

import napa.SignatureRecognition.Point;
import napa.SignatureRecognition.Signature;
import napa.SignatureRecognition.Signature_templates;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.project.R;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.InstanceCreator;
//import com.kau.lockmyapp.utils.IService;

public class ReSetSignLockScreenActivity extends Activity implements ServiceConnection{
//generic variables		
	private SharedPreferences sp;
	private String str;
	private int attemptCnt = 0;
	private static final int SIGNATURE_ATTEMPTS = 2;
	private static boolean doneSignAttempts = false;
	private static boolean isSignFinish = false;					//napa 
//application specific variables	
	private Button btnErase;
	private static Button btnSign;
	private TextView txt_signView, txt_msgView;
	private View signView;
	private int longAnimDuration;
	private ImageView iv_icon;
	private TextView tv_packname;
	private String signature_status;
	private double dwt_threshold;
	private double hist_threshold;
	private double score_DTW;
	private double score_hist;
	private Drawable localDrawable;
	private static final String TAG = "ReSetSignLockScreenActivity";
	Intent intent1, intent2;
	Handler hd=new Handler();
	
	public static boolean isTouched = false;		

	private WindowManager manager;
	private WindowManager.LayoutParams localLayoutParams;
   
    customViewGroup view;
	@Override
	public void onBackPressed() {
	    // Do nothing
	}

//	private IService iService = new IService() {
//		
//		@Override
//		public void setSignFinish(boolean logic) {
//			// TODO Auto-generated method stub
//			isSignFinish = logic;
//		}
//		
//		@Override
//		public void setDoneSignAttempts(boolean result) {
//			// TODO Auto-generated method stub
//			doneSignAttempts = result;
//		}
//	};
	
	// destroy if home or back pressed
	protected void onStop() {
		super.onStop();						
//		iService.setSignFinish(true);		//napa
		finish();
	}	
	
	@Override
	public void onServiceConnected(ComponentName name, IBinder service) {
//		this.iService = ((IService)service); 		
	}

	@Override
	public void onServiceDisconnected(ComponentName name) {
		// TODO Auto-generated method stub
		
	}
	@Override
	protected void onDestroy() {		
		super.onDestroy();
		//unbindService(this);
	}
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);	
		Log.d("==================", "on create");
//	    intent1 = new Intent(this, SignLockScreenActivity1.class);
//	    intent2 = new Intent(this, SignLockScreenActivity1.class);	
	    initService();
		initUI();
		Toast.makeText(getApplicationContext(), "re", Toast.LENGTH_LONG).show();
		
	}	
	//This is to initialize service
	private void initService()
	{
		Log.d("==================", "Loading Templates");
		//Initialize SharedPreference			
		sp = getSharedPreferences("lock_config", 0);
		////LOAD TEMPLATES
		loadTemplates(sp);		
		
	}
	
		
	//Call when the credential is not authentic and attempts are finished	
	private void failAuthenticate()
	{	
		txt_signView.setEnabled(false);
	}

	
//****Application specific method	
	
	class SignatureInstanceCreator implements InstanceCreator<Signature> {
		   public Signature createInstance(Type type) {
		     return new Signature(null);
		   }
	}	

	//This is to initialize UI	
	private void initUI()
	{
		setContentView(R.layout.reset_sign_n_unlock);	
		
		
		
		manager = ((WindowManager) getApplicationContext().getSystemService(Context.WINDOW_SERVICE));

		 android.view.WindowManager.LayoutParams localLayoutParams = new WindowManager.LayoutParams();
		 localLayoutParams.type = WindowManager.LayoutParams.TYPE_SYSTEM_ERROR;
		 localLayoutParams.gravity = Gravity.TOP;    

		 localLayoutParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|

//		 WindowManager.LayoutParams.FLAG_LAYOUT_ATTACHED_IN_DECOR |
		 WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN |

		 // this is to enable the notification to recieve touch events
//		 WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN |
		 WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH |
       // Draws over status bar
		 WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;


		 //localLayoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
		 localLayoutParams.height = (int) (50 *      getResources().getDisplayMetrics().scaledDensity);
		 localLayoutParams.format = PixelFormat.TRANSPARENT;

		 view = new customViewGroup(this);

		 manager.addView(view, localLayoutParams); 

		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);	//napa
		//View objects
		//final TextView txt_msg = (TextView) findViewById(R.id.txt_msg);
		//txt_msg.setBackgroundColor(Color.DKGRAY);
		
		Log.d("==================", "i am here");
		btnErase = (Button) findViewById(R.id.btnErase);
		btnSign = (Button) findViewById(R.id.btnSign);
		btnSign.setEnabled(true);
		txt_signView = (TextView) findViewById(R.id.txt_signView); 
		txt_msgView = (TextView) findViewById(R.id.txt_msg);
		signView = findViewById(R.id.signview);		
			
			//Get lock app icon and name
		//tv_packname = ((TextView)findViewById(R.id.tv_app_lock_pwd_name));		
//	    iv_icon = ((ImageView)findViewById(R.id.iv_app_lock_pwd_icon));				
	    
	//This is to modify UI after information on application-to-be-launched name and icon image have been set	
		if (localDrawable!= null)// localApplicationInfo is found
		{			
	        this.tv_packname.setText(str);
	        this.iv_icon.setImageDrawable(localDrawable);	        
		}
		//CROSSFADE ANIMATION - Hide visibility of signView		
		txt_signView.setText("Sign here to unlock this app");
		txt_signView.setVisibility(View.VISIBLE);				
		longAnimDuration = 3000;						
		ReSetSignLockScreenActivity.this.crossfade();				
		
	//ERASE BUTTON ONCLICK				
		btnErase.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {ReSetBitmapView.btnReset.callOnClick();}		});				
	//SIGN BUTTON ONCLICK				
		btnSign.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {				
				if(sp.getInt("mode", 1) == ReSetSignature.TESTMODE) {				
					//Log.d(TAG, "TEST MODE: " + ReSetBitmapView.interaction.toString());
//					Toast.makeText(getApplicationContext(), "Sign Check 2 : "+ReSetBitmapView.interaction, Toast.LENGTH_LONG).show();

					if(isTouched)   
					{						
						if(isSignatureVerified(ReSetBitmapView.interaction)) 
						{
							startActivity(new Intent(getApplicationContext(), ReSetDrawSignature.class)); 
							finish();
						}
						else {
							retry();
						}
						isTouched = false;
					}
					else
					{
						Toast.makeText(getApplicationContext(), "Please Sign to Continue !!!", Toast.LENGTH_LONG).show();
					}
				}
			}
		});		
	}
	//Call when the credential is not authentic and attempts are not finished
	private void retry()
	{
		txt_msgView.setTextColor(Color.RED);
		ReSetSignLockScreenActivity.this.crossfade();
		txt_msgView.setText("Invalid Signature!");
		resetDataAndUI();
	}

	//This is to reset authentication credential data and UI after a failed attempt has been made
	private void resetDataAndUI()
	{
		ReSetBitmapView.btnReset.callOnClick();
		ReSetBitmapView.interaction = new ArrayList<ArrayList<Point>>();
		btnSign.setEnabled(false);
	}
	//This is to load credential template from SharedPreferences
	private void loadTemplates(SharedPreferences sp) {
	 String un=sp.getString("uname", "");
//	 Toast.makeText(getApplicationContext(),"un"+un,Toast.LENGTH_LONG).show();
	 SQLiteDatabase sqldb =openOrCreateDatabase("project",SQLiteDatabase.CREATE_IF_NECESSARY ,null );
     sqldb.setVersion(1);
     sqldb.setLocale(Locale.getDefault());
     String sql="create table if not exists signt(uname text primary key, template text)";
     sqldb.execSQL(sql);
     String s="select * from signt where uname='"+un+"'"; 
     Cursor cr=sqldb.rawQuery(s, null);
     
     String u="";
     if(cr.getCount()!=0)
     {
    	 cr.moveToNext();
    	 u=cr.getString(1);    	 
     }
     
//     	Toast.makeText(getApplicationContext(), "res"+u, Toast.LENGTH_LONG).show();
		if(sp.getInt("mode", 1) == ReSetSignature.TESTMODE) {
			Log.d(TAG, "yo..its test mode");
				//Gson gson = new Gson();
				Gson gson = new GsonBuilder().registerTypeAdapter(Signature.class, new SignatureInstanceCreator()).create();
				String json;				
				Signature temp;
				ArrayList<Signature> templates = new ArrayList<Signature>();
//				for(int i=1;i<=MainSignature.TOTAL_TEMPLATES; i++) 
//				{
				//int i=1;
					  String res[]=u.split("#@#");
					  Log.d("============================", "i am here res size : "+res.length);
					  for(String result : res)
					  {
//						 SharedPreferences.Editor editor = sp.edit();
//						 editor.putString("my_templates" + i, result);
//						 editor.commit();
//					  
						 json = result;//sp.getString("my_templates" + i, "");
//						 Log.d(TAG, "Reloaded json" + i + ": " + json);
//						 Toast.makeText(getApplicationContext(),"log"+json, Toast.LENGTH_LONG).show();
						 temp = gson.fromJson(json, Signature.class);
						 templates.add(temp);
					  }
				//}
				Log.d(TAG, "temp size : "+templates.size());
				if(templates.size() == 5) {
					Log.e(TAG, "Reloaded templates size: " + templates.size());
					ReSetSignature.user_profile.setTemplates(templates);	
					//Toast.makeText(getApplicationContext(), "Temp Count : "+MainSignature.user_profile.getTraingingSamplesCount(), Toast.LENGTH_LONG).show();
					Log.e(TAG, "Reloaded templates size: " + ReSetSignature.user_profile.getTraingingSamplesCount());
				} else {
					Log.e(TAG, "Invalid template loaded!");
				}
		} else {
			Log.d(TAG, "Still set to Trainmode..");
		}
	}
	
		
	private void crossfade() {
		txt_signView.setAlpha(0f);
		txt_signView.setVisibility(View.VISIBLE);
		txt_signView.animate().alpha(1f).setDuration(longAnimDuration).setListener(null);	
		
		signView.animate().alpha(1f).setDuration(longAnimDuration).setListener(new AnimatorListenerAdapter() {
			@Override
			public void onAnimationEnd(Animator animation) {
				txt_signView.setVisibility(View.GONE);
				signView.setVisibility(View.VISIBLE);				
			}
		});
	}
	
	private boolean isSignatureVerified(ArrayList<ArrayList<Point>> rawInteraction) {    	
    	boolean result = false;
    	signature_status = "INVALID";
    	if (ReSetSignature.user_profile.getTraingingSamplesCount()==ReSetSignature.TOTAL_TEMPLATES) {
    		ArrayList<ArrayList<Point>> matchInteraction = new ArrayList<ArrayList<Point>>();
    		for (int j = 0;j<rawInteraction.size();j++) {
    				matchInteraction.add(rawInteraction.get(j));
    		}
    		
    		double[] score = ReSetSignature.user_profile.distance_score(matchInteraction);
    		score_DTW = score[0];
    		score_hist = score[1];
    		//Toast.makeText(getApplicationContext(), "Check : "+score[0]+"---"+score[1], Toast.LENGTH_LONG).show();
    		
//    		if ((score_DTW >= Signature_templates.getDWTThreshold()) && (score_hist <= Signature_templates.getHISTThreshold())) {        			
//    			result = true;    		    				
//    		}
    		dwt_threshold = sp.getFloat("dwt_threshold", 0);
    		hist_threshold = sp.getFloat("hist_threshold", 0);
    		if(dwt_threshold == 0 || dwt_threshold == 2 ) {
    			dwt_threshold = Signature_templates.getDWTThreshold();
    		}
    		if(hist_threshold == 0 || hist_threshold == 30) {
    			
    			hist_threshold = Signature_templates.getHISTThreshold();
    		}
    		Log.d("dddddddddddd", ""+hist_threshold+"======="+dwt_threshold);
//    		Toast.makeText(getApplicationContext(), "Set DWT threshold: " + dwt_threshold + "\n Set HIST threshold: " + hist_threshold, Toast.LENGTH_LONG).show();
    		
    		if ((score_DTW <= dwt_threshold) && (score_hist <= hist_threshold)) {        			

    			result = true;
    			signature_status = "VALID";
    		}
    		matchInteraction.clear();
    		Log.d(TAG, ""+signature_status);
    		//Toast.makeText(getApplicationContext(), "Status : "+signature_status+"---"+result, Toast.LENGTH_LONG).show();
    		
    	}    	
    	return result;
    }
		
	public static void enableSignButton() {
		if(btnSign != null) {
			btnSign.setEnabled(true);
		}
	}
	
//	Runnable r=new Runnable() {
//		
//		@Override
//		public void run() {
//			// TODO Auto-generated method stub
//			try {
//				
//				Intent i=new Intent(getApplicationContext(),ReSetSignature.class);
//				startActivity(i);
//			} catch (Exception e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		}
//	};

}