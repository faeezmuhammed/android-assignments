package com.kau.lockmyapp.sign;

import com.example.project.Home;
import com.example.project.R;

import android.app.Activity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;


public class SetSignatureParameters extends Activity {
	
	private SeekBar seekBarDWT;
	private TextView statusDWT;
	private SeekBar seekBarHIST;
	private TextView statusHIST;
	private SharedPreferences sp;
	

	private WindowManager manager;
	private WindowManager.LayoutParams localLayoutParams;
   
    customViewGroup view;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.signature_param_settings);
		
		
		
		manager = ((WindowManager) getApplicationContext().getSystemService(Context.WINDOW_SERVICE));

		 android.view.WindowManager.LayoutParams localLayoutParams = new WindowManager.LayoutParams();
		 localLayoutParams.type = WindowManager.LayoutParams.TYPE_SYSTEM_ERROR;
		 localLayoutParams.gravity = Gravity.TOP;    

		 localLayoutParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|

//		 WindowManager.LayoutParams.FLAG_LAYOUT_ATTACHED_IN_DECOR |
		 WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN |

		 // this is to enable the notification to recieve touch events
//		 WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN |
		 WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH |
       // Draws over status bar
		 WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;


		 //localLayoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
		 localLayoutParams.height = (int) (50 *      getResources().getDisplayMetrics().scaledDensity);
		 localLayoutParams.format = PixelFormat.TRANSPARENT;

		 view = new customViewGroup(this);

		 manager.addView(view, localLayoutParams); 

		
		
		
		
///*--------------------------Home & Status--------------------------*/
//		
//		// Set the IMMERSIVE flag.
//	    // Set the content to appear under the system bars so that the content
//	    // doesn't resize when the system bars hide and show.
//	    this.getWindow().getDecorView().setSystemUiVisibility(
//	            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
//	            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
//	            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
//	            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION // hide nav bar
//	            | View.SYSTEM_UI_FLAG_FULLSCREEN // hide status bar
//	            | View.SYSTEM_UI_FLAG_IMMERSIVE);
//	    
//	    /*------------------------------End--------------------------------*/
//		
//		
		
		sp = getSharedPreferences("lock_config", 0);
		
		seekBarDWT = (SeekBar) findViewById(R.id.seekbar);
		seekBarDWT.setProgress( ((int)sp.getFloat("dwt_threshold", 0)) - 2 );
		statusDWT = (TextView) findViewById(R.id.seekbar_title);
		statusDWT.setText("DWT: " + sp.getFloat("dwt_threshold", 0));
		
		seekBarHIST = (SeekBar) findViewById(R.id.seekbar2);
		seekBarHIST.setProgress( ((int)sp.getFloat("hist_threshold", 0)) - 30 );
		statusHIST = (TextView) findViewById(R.id.seekbar_title2);
		statusHIST.setText("Hist: " + sp.getFloat("hist_threshold", 0));
		
		//final EditText txt_dwt = (EditText) findViewById(R.id.txt_dwt);
		//final EditText txt_hist = (EditText) findViewById(R.id.txt_hist);
		//Button btn_set_params = (Button) findViewById(R.id.btn_set_params);
		
		//txt_dwt.setText("" + sp.getFloat("dwt_threshold", 0));
		//txt_hist.setText("" + sp.getFloat("hist_threshold", 0));
		
		
		seekBarDWT.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
            int progressChanged = 0;
 
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser){
                progressChanged = progress;
                statusDWT.setText("DWT: " + Integer.valueOf(progress+2).toString());
            }
 
            public void onStartTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
            }
 
            public void onStopTrackingTouch(SeekBar seekBar) {
                //Toast.makeText(SetSignatureParameters.this,"New setting: " + (progressChanged+2) + ".", Toast.LENGTH_SHORT).show();
                
                SharedPreferences.Editor editor = sp.edit();
                editor.putFloat("dwt_threshold", progressChanged+2).commit();
            }
        });
		
		
		
		seekBarHIST.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
            int progressChanged = 0;
 
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser){
                progressChanged = progress;
                statusHIST.setText("Hist: " + Integer.valueOf(progress+30).toString());
            }
 
            public void onStartTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
            }
 
            public void onStopTrackingTouch(SeekBar seekBar) {
                //Toast.makeText(SetSignatureParameters.this,"New setting: " + (progressChanged+30) + ".", Toast.LENGTH_SHORT).show();
                
                SharedPreferences.Editor editor = sp.edit();
                editor.putFloat("hist_threshold", progressChanged+30).commit();
            }
        });
		
		
		
		/*
		btn_set_params.setOnClickListener(new OnClickListener() {			
			@Override
			public void onClick(View v) {
				SharedPreferences.Editor editor = sp.edit();
				String dwt_threshold = txt_dwt.getText().toString();
				String hist_threshold = txt_hist.getText().toString();
				
				if(dwt_threshold.length() > 0) {
					editor.putFloat("dwt_threshold", Float.parseFloat(dwt_threshold));
				}
				
				if(hist_threshold.length() > 0) {
					editor.putFloat("hist_threshold", Float.parseFloat(hist_threshold));
				}
				editor.commit();
				Toast.makeText(SetSignatureParameters.this, "Threshold values are set.", Toast.LENGTH_SHORT).show();
				
				Intent intent = new Intent(SetSignatureParameters.this, ApplicationList.class);
				startActivity(intent);
				finish();
			}
		});
		*/
			
	}
	
	public void goBack(View v) {
		Intent intent = new Intent(SetSignatureParameters.this, Home.class);
		startActivity(intent);
		finish();
	}
}

