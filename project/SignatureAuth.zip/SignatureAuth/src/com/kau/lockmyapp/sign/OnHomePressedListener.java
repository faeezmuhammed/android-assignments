package com.kau.lockmyapp.sign;

public interface OnHomePressedListener {
    public void onHomePressed();

    public void onHomeLongPressed();
}