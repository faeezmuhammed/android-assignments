package com.kau.lockmyapp.sign;

import java.util.ArrayList;

import napa.SignatureRecognition.Point;
import napa.SignatureRecognition.Signature;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Bundle;
import android.provider.Settings.Secure;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.project.Home;
import com.example.project.R;
import com.google.gson.Gson;

public class DrawSignature extends Activity {
	
	private static int counter = 1;

	private Button btnErase;
	private static Button btnNext;
	private TextView txt_signView;
	private View signView;
	private int longAnimDuration;
	private SharedPreferences sp;

	private static final int MIN_SEQ = 3;
	String un="";
	public static ArrayList<String> json_templates = new ArrayList<String>();

	private static final String TAG = "DrawSignature";

	public static ArrayList<Float> pointXArr;
	public static ArrayList<Float> pointYArr;
	public static ArrayList<String> eventTypeArr;
	public static ArrayList<Long> timestampArr;
	
	public static boolean isTouched = false;
	
	private WindowManager manager;
	
    customViewGroup view;

	static{
		pointXArr = new ArrayList<Float>();
		pointYArr = new ArrayList<Float>();
		eventTypeArr = new ArrayList<String>();
		timestampArr = new ArrayList<Long>();
	}
	protected void onStop() {
	    MainSignature.user_profile.clearAllTemplate();		
		super.onStop();							    
	}

	@Override
	public void onBackPressed() {
	    MainSignature.user_profile.clearAllTemplate();		
	    super.onBackPressed();
	}
	public void resetDone()
	{
		SharedPreferences.Editor editor = sp.edit();
		editor.putBoolean("isSignatureSet", true);
		editor.commit();
		storeTemplates();
		
		//-----------------------------------
//		Intent intent = new Intent(DrawSignature.this,LoginSignature.class);
//	    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
//		startActivity(intent);
		Intent intent = new Intent(DrawSignature.this,Home.class);
	    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
		startActivity(intent);
		//----------------------------------------
		DrawSignature.this.finish();	
	}
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_sig);
		
		manager = ((WindowManager) getApplicationContext().getSystemService(Context.WINDOW_SERVICE));

		 android.view.WindowManager.LayoutParams localLayoutParams = new WindowManager.LayoutParams();
		 localLayoutParams.type = WindowManager.LayoutParams.TYPE_SYSTEM_ERROR;
		 localLayoutParams.gravity = Gravity.TOP;    

		 localLayoutParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|
		 
		 WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN |

		 WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH |
         // Draws over status bar
		 WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;


		 localLayoutParams.height = (int) (50 *      getResources().getDisplayMetrics().scaledDensity);
		 localLayoutParams.format = PixelFormat.TRANSPARENT;

		 view = new customViewGroup(this);

		 manager.addView(view, localLayoutParams); 

		//Initialize SharedPreference
		sp = getSharedPreferences("lock_config", 0);
        un=sp.getString("uname", "");
       
		//View objects
		final TextView txt_msg = (TextView) findViewById(R.id.txt_msg);
		txt_msg.setBackgroundColor(Color.DKGRAY); 
		btnErase = (Button) findViewById(R.id.btnErase);
		btnNext = (Button) findViewById(R.id.btnNext);
		btnNext.setEnabled(true);
		txt_signView = (TextView) findViewById(R.id.txt_signView);
		signView = findViewById(R.id.signview);

		//CROSSFADE ANIMATION - Hide visibility of signView
		txt_signView.setVisibility(View.VISIBLE);
		longAnimDuration = 3000;
		DrawSignature.this.crossfade();


		//ERASE BUTTON ONCLICK
		btnErase.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				isTouched = false; 
				BitmapView.btnReset.callOnClick();
				clearData();  
			}     
		});

		//NEXT BUTTON ONCLICK
		btnNext.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {

				if(sp.getInt("mode", 1) == MainSignature.TRAINMODE) 
				{
				
					if(isTouched)   
					{
						//Add interaction to template
						onTrain(BitmapView.interaction);
	
						longAnimDuration = 1000;
	
						//Send Data to server
						if(sp.getInt("mode", 1) == MainSignature.TRAINMODE) {
							Log.d(TAG, "Sending data to server...");
							Log.d(TAG, "pointXArr: " + pointXArr.toString());
						}
						switch(MainSignature.user_profile.getTraingingSamplesCount()) {
							case 1:
								txt_signView.setText("Four more to go!");
								txt_msg.setText("Four more!");
								break;
							case 2:
								txt_signView.setText("Three more to go!");
								txt_msg.setText("Three more!");
								break;
							case 3:
								txt_signView.setText("Two more to go!");
								txt_msg.setText("Two more!");
								break;
							case 4:
								txt_signView.setText("One more to go!");
								txt_msg.setText("One more!");
								break;
							
	
							default:
								txt_signView.setText("Training Mode");
								break;
							}
							DrawSignature.this.crossfade();
							isTouched = false;
							counter++;
						}
						else
						{
							Toast.makeText(getApplicationContext(), "Please Sign to Continue !!!", Toast.LENGTH_LONG).show();
						}
						//IF DONE WITH TRAINING
						if ( MainSignature.user_profile.getTraingingSamplesCount()==MainSignature.TOTAL_TEMPLATES) {
							counter = 1;
							resetDone();
						}
					}
					BitmapView.btnReset.callOnClick();
					BitmapView.interaction = new ArrayList<ArrayList<Point>>();
					btnNext.setEnabled(true);
				}

		});
	}
	public void storeTemplates() {
		ArrayList<Signature> templates = MainSignature.user_profile.getTemplates();
		if(templates.size() > 0) { 
			SharedPreferences.Editor editor = sp.edit();
			//SET MODE TO TEST
			Log.d(TAG, "hereeeee....setting mode to test");
			editor.putInt("mode", MainSignature.TESTMODE);
			//STORE TEMPLATES
			Gson gson = new Gson();
			int i=1;
			String json="";
			for (Signature template : templates) {
				 json =json+ gson.toJson(template)+"#@#";
				 i++;
			}
			editor.putString("isReg", "true");
			editor.commit();

			SQLiteDatabase db=openOrCreateDatabase("project", SQLiteDatabase.CREATE_IF_NECESSARY, null);
			String sql="create table if not exists signt(uname text primary key, template text)";
	        db.execSQL(sql);
	        String re="update signt set template='"+json+"' where uname='"+un+"'";
		    db.execSQL(re);
	       
	      
           db.close();
        } else {}
	}
	
	public static void clearData() {
		pointXArr.clear();
		pointYArr.clear();
		eventTypeArr.clear();
		timestampArr.clear();
	}

	private String getAndroidId() {
		String android_id = Secure.getString(getContentResolver(),Secure.ANDROID_ID);
		return android_id;
	}

	private void crossfade() {
		txt_signView.setAlpha(0f);
		txt_signView.setVisibility(View.VISIBLE);
		txt_signView.animate().alpha(1f).setDuration(longAnimDuration).setListener(null);

		signView.animate().alpha(1f).setDuration(longAnimDuration).setListener(new AnimatorListenerAdapter() {
			@Override
			public void onAnimationEnd(Animator animation) {
				txt_signView.setVisibility(View.GONE);
				signView.setVisibility(View.VISIBLE);
			}
		});
	}

	private void onTrain(ArrayList<ArrayList<Point>> rawInteraction) {
    	int i = 0;
    	while (i<rawInteraction.size()) {
    		if (rawInteraction.get(i).size()!=1) {
    			rawInteraction.get(i).clear();
    			rawInteraction.remove(i);
    		} else {// just one
    			i = i+1;
    		}
    	}

    	if (rawInteraction.size()<MIN_SEQ) {
    		
    	} else {
    		MainSignature.user_profile.addTemplate(rawInteraction);
    	}
    }

	public static void enableNextButton() {
		btnNext.setEnabled(true);
	}

}